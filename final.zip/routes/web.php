<?php

use App\Events\Ludogame;
use App\Events\Piece;
use App\Http\Controllers\GameController;
use App\Events\PicePlayer;
use Illuminate\Support\Facades\Route;


Route::get ( '/join/{room_id}/{user_name}', [GameController::class,'join'])->name('join');

 
    
    // Route::get('/ludo/{piece}/{player}', function ($piece, $player) {
    //     // Broadcast the piece click event
           
    //     event(new Piece($piece));
    //     return response()->json(['message' => 'Piece click broadcasted!']);
    // });
    Route::get('/ludo/{piece}/{player}', function ($piece, $player) {
        // Broadcast the dice value event
        $data = [
'pice'=>$piece,
'player' => $player
        ];
        event(new PicePlayer($data));
        return response()->json(['message' => 'Pice Data roll broadcasted!']);
    });
    

    Route::get('/ludo/roll-dice/{diceValue}/{player}', function ($diceValue, $player) {
        // Broadcast the dice value event
        event(new Ludogame($diceValue));
        return response()->json(['message' => 'Dice roll broadcasted!']);
    });
    



    Route::get('/ludo/checkroom/{room_id}/{user_name}',[GameController::class,'checkgame'])->name('checkroom');
    Route::get('/create/{room_id}/{user_name}',[GameController::class,'create_room']);
    Route::get('/start-game/{room_id}',[GameController::class,'startgame']);
    Route::get('/get-room/{room_id}', [GameController::class, 'getRoom']);
