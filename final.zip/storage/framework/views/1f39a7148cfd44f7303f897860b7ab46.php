<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LudoJS Tutorial</title>
    <link rel="stylesheet" href="/js/ludo/style.css">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js', 'resources/css/app.css']); ?>
    <style>
        body {
          display: flex;
          justify-content: center;
          align-items: center;
          height: 40vh;
          margin: 0;
          background-image:url('bannar.jpg');
        }
  
        .card {
        width: 73px;
        height: 139px;
        border: 5px solid #d8e03e;
        border-radius: 10px;
        overflow: hidden;
        transform: rotate(-90deg);
        position: relative;
        top: 28.3rem;
        left: 2rem;

        }

        .cardtwo {
        width: 73px;
        height: 139px;
        border: 5px solid #d8e03e;
        border-radius: 10px;
        overflow: hidden;
        transform: rotate(-90deg);
        position: relative;
        bottom: -52.3rem;
        left: 2rem;

        }


        .cardt {
        width: 73px;
        height: 139px;
        border: 5px solid #d8e03e;
        border-radius: 10px;
        overflow: hidden;
        transform: rotate(-90deg);
        position: relative;
        top: 10.6rem;
        left: 21.4rem;

        }


        .cardf {
        width: 73px;
        height: 139px;
        border: 5px solid #d8e03e;
        border-radius: 10px;
        overflow: hidden;
        transform: rotate(-90deg);
        position: relative;
        top: 35rem;
    left: 21.5rem;
        }
  
        .top-section {
          background: linear-gradient(to bottom, #1b5dab, #96c0de);
          height: 45%;
          display: flex;
          justify-content: center;
          align-items: center;
        }
  
        .bottom-section {
          background-color: #f5c5c7;
          height: 55%;
        }
      </style>
</head>

<body>
    <div class="ludo-container">
        <div class="card">
            <div class="top-section">
              <div class="teardrop">
                <div class="circle">
                  <img
                   style="width: 38%; position: relative; left: 28%; transform: rotate(90deg);"
                    src="/piece.png"
                    alt=""
                  />
                </div>
              </div>
            </div>
            <div class="bottom-section"></div>
          </div>

          <div class="cardtwo">
            <div class="top-section">
              <div class="teardrop">
                <div class="circle">
                  <img
                   style="width: 38%; position: relative; left: 28%; transform: rotate(90deg);"
                    src="/piece.png"
                    alt=""
                  />
                </div>
              </div>
            </div>
            <div class="bottom-section"></div>
          </div>

          <div class="cardt">
            <div class="top-section">
              <div class="teardrop">
                <div class="circle">
                  <img
                   style="width: 38%; position: relative; left: 28%; transform: rotate(90deg);"
                    src="/piece.png"
                    alt=""
                  />
                </div>
              </div>
            </div>
            <div class="bottom-section"></div>
          </div>

          <div class="cardf">
            <div class="top-section">
              <div class="teardrop">
                <div class="circle">
                  <img
                   style="width: 38%; position: relative; left: 28%; transform: rotate(90deg);"
                    src="/piece.png"
                    alt=""
                  />
                </div>
              </div>
            </div>
            <div class="bottom-section"></div>
          </div>

        <div class="ludo">
            <div class="player-pieces">
                <div class="player-piece" player-id="P1" piece="0"></div>
                <div class="player-piece" player-id="P1" piece="1"></div>
                <div class="player-piece" player-id="P1" piece="2"></div>
                <div class="player-piece" player-id="P1" piece="3"></div>

                <div class="player-piece" player-id="P2" piece="0"></div>
                <div class="player-piece" player-id="P2" piece="1"></div>
                <div class="player-piece" player-id="P2" piece="2"></div>
                <div class="player-piece" player-id="P2" piece="3"></div>
            </div>

            <div class="player-bases">
                <div class="player-base" player-id="P1"></div>
                <div class="player-base" player-id="P2"></div>
            </div>
        </div>
        <div class="testdata">


        </div>
        <div class="footer">
            <div class="row">
                <button id="dice-btn" class="btn btn-dice" style="margin-top:5rem">Roll:</button>
                <div class="dice-value"></div>
                <button id="reset-btn" class="btn btn-reset">Reset</button>
            </div>
            <h2 class="active-player">Active Player: <?php echo e($user_name); ?><span></span> </h2>
        </div>
    </div>






    <script src="/js/main.js" type="module"></script>

    <!-- Initialize Echo channel -->
    


</body>

</html>
<?php /**PATH C:\for git\ludogame\ludogamews\resources\views/ludo.blade.php ENDPATH**/ ?>