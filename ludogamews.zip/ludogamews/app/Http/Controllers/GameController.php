<?php

namespace App\Http\Controllers;
use App\Models\Room; // Correctly importing the Room model
use Illuminate\Http\Request;
class GameController extends Controller
{
    public function checkgame(Request $request, $room_id, $user_name)
    {
        // Correct variable name
        $room = Room::where('room_id', $room_id)->first();
        $join = false;
        return view('joinroom',compact('room','room_id','user_name','join'));

        // This won't be reached due to dd() above, so it's unnecessary
        // dd($room_id, $user_name);
    }
 
    
    public function create_room($room_id, $user_name)
    { 
        // Create a new Room instance
        $room = new Room;
        $room->room_id = $room_id;
        $room->user_count = "1";
        $room->first_user = $user_name;
        $room->status = 'pending';
        $room->save();
       
        // Return URL with success message
        return redirect()->route('checkroom', ['room_id' => $room_id, 'user_name' => $user_name ]);


    }
    

   
    public function join($room_id,$user_name)
    {
        $room = Room::where('room_id',$room_id)->first();
        if($room->sec_user){
            $room->user_count += "1";
        }else{
            $room->sec_user = $user_name;
        }
        $room->save();
        $join = true;
       
        return redirect()->route('checkroom', ['room_id' => $room_id, 'user_name' => $user_name , 'join'=>$join]);

    } 



  public function startgame($room_id)
  {
    $room = Room::where('room_id',$room_id)->first();
    $room->status = "start";
    $room->save();
    $user_name = $room->first_user;
    return view('ludo',compact('user_name'));

  }
  public function getRoom($room_id) {
    // Retrieve the room based on room_id
    $room = Room::where('room_id', $room_id)->first(); // Use first() to get a single room

    // Check if the room exists
    if (!$room) {
        return response()->json(['error' => 'Room not found'], 404);
    }

    return response()->json($room); // Return the room data as JSON
}




}


