<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Room</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background-color: white;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            border-radius: 8px;
            text-align: center;
            width: 300px;
        }
        h1 {
            color: #333;
        }
        .room-info {
            margin-bottom: 20px;
        }
        .room-info h2 {
            font-size: 24px;
            margin: 10px 0;
        }
        .room-info p {
            font-size: 18px;
            color: #666;
        }
        .btn {
            display: inline-block;
            padding: 10px;
            text-decoration: none;
            margin-top: 10px;
        }
        .join-btn img, .create-btn img {
            width: 50px;
            height: 50px;
        }
        .create-room {
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php if($room): ?>
            <div class="room-info">
                <h2>Room Details</h2>
                <p><strong>User Count:</strong> <?php echo e($room->user_count); ?></p>
                <p><strong>Create By:</strong> <?php echo e($room->first_user); ?></p>
                <?php if($room->sec_user): ?>
                <p><strong>Oposite player:</strong> <?php echo e($room->sec_user); ?></p>
            <?php endif; ?>
            
                <p><strong>Status:</strong> <?php echo e($room->status); ?></p>
            </div>
            <div>
            <a class="btn join-btn d-flex flex-column align-items-center">
                <img src="https://cdn-icons-png.flaticon.com/512/1077/1077063.png" alt="Join Room" />
                <span style="position: relative; top: 19px; right: 3rem;"><?php echo e($room->first_user); ?></span>
            </a>
            <?php if($room->sec_user): ?>
            <a class="btn join-btn d-flex flex-column align-items-center">
                <img src="https://cdn-icons-png.flaticon.com/512/1077/1077063.png" alt="Join Room" />
                <span style="position: relative; top: 19px; right: 3rem;"><?php echo e($room->sec_user); ?></span>
            </a>
            <?php endif; ?>
            <?php if($user_name !== $room->sec_user && $user_name !== $room->first_user && !$join): ?>
            <a href="/join/<?php echo e($room_id); ?>/<?php echo e($user_name); ?>" class="btn join-btn d-flex flex-column align-items-center">
                <img style="position: relative; left: 1rem;" src="/adduser.png" alt="Join Room" />
                <span style="position: relative; top: 19px; right: 3rem;">Join Room</span>
            </a>
            <?php endif; ?>

           
        </div>


        <?php if($user_name == $room->first_user): ?>
        <a href="/start-game/<?php echo e($room_id); ?>" class="btn" style="background: skyblue; margin-top: 2rem; color: black; border-radius: 2rem;"> Start Game</a>
    <?php endif; ?>
        <?php else: ?>
            <div class="create-room">
                <h1>Create a New Room</h1>
                <a href="/create/<?php echo e($room_id); ?>/<?php echo e($user_name); ?>" class="btn create-btn">
                    <img src="https://cdn-icons-png.flaticon.com/512/1077/1077063.png" alt="Create Room" />
                </a>
            </div>
        <?php endif; ?>
    </div>
    <script>
        const roomId = "<?php echo e($room_id); ?>"; // Pass the room_id from Blade
        let lastRoomState = <?php echo json_encode($room); ?>; // Store the initial room state
    
        // Function to check for room updates
        function checkRoomUpdate() {
            fetch(`/get-room/${roomId}`)
                .then(response => response.json())
                .then(room => {
                    // Check if the room data has changed
                    const isStatusChanged = room.status !== lastRoomState.status;
                    const isDataChanged = JSON.stringify(room) !== JSON.stringify(lastRoomState);
    
                    // Update last room state
                    lastRoomState = room;
    
                    // Debugging logs
                    console.log('Current Room Status:', room.status);
                    console.log('Last Room Status:', lastRoomState.status);
    
                    // Redirect if the status changes to "start"
                    if (room.status == "start") {
                        window.location.href = `/start-game/${roomId}`;
                    } 
                    // Reload the page for other changes
                    else if (isDataChanged) {
                        console.log("Reloading the page due to data change...");
                        location.reload();
                    }
                })
                .catch(error => console.error("Error fetching room data:", error));
        }
    
        // Poll every second (1000 milliseconds)
        setInterval(checkRoomUpdate, 1000);
    </script>
    
    
</body>
</html>
<?php /**PATH C:\laragon\www\ludogamews\resources\views/joinroom.blade.php ENDPATH**/ ?>